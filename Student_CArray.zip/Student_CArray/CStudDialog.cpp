// CStudDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Student_CArray.h"
#include "CStudDialog.h"
#include "afxdialogex.h"


// CStudDialog dialog

IMPLEMENT_DYNAMIC(CStudDialog, CDialog)

CStudDialog::CStudDialog(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_NEWDIALOG, pParent)
	//, m_StudentName(_T(""))
{

}

CStudDialog::~CStudDialog()
{
}

void CStudDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//  DDX_Text(pDX, IDC_EDIT1, m_StudentName);
	//  DDV_MaxChars(pDX, m_StudentName, 10);
}


BEGIN_MESSAGE_MAP(CStudDialog, CDialog)
END_MESSAGE_MAP()


// CStudDialog message handlers
