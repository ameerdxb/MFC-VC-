#include "stdafx.h"
#include "CMyStudent.h"


CMyStudent::CMyStudent()
{
}


CMyStudent::~CMyStudent()
{
}
