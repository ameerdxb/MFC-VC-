// Student_CArrayDlg.h : header file
//

#if !defined(AFX_STUDENT_CARRAYDLG_H__E87596D5_A5F4_4F46_A5FF_9B87DDA75E8F__INCLUDED_)
#define AFX_STUDENT_CARRAYDLG_H__E87596D5_A5F4_4F46_A5FF_9B87DDA75E8F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CStudent_CArrayDlg dialog
 
#include"Student.h"
#include<afxtempl.h>

class CStudent_CArrayDlg : public CDialog
{
// Construction
public:
	void Display(CStudent&);
	CStudent_CArrayDlg(CWnd* pParent = NULL);	// standard constructor
	CArray<CStudent,CStudent&> arr;

// Dialog Data
	//{{AFX_DATA(CStudent_CArrayDlg)
	enum { IDD = IDD_STUDENT_CARRAY_DIALOG };
	CString	m_Name;
	int		m_Regno;
	int		m_Age;
	int		m_Marks;
	CString	m_RecordNumber;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStudent_CArrayDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	int m_nPos;
	

	// Generated message map functions
	//{{AFX_MSG(CStudent_CArrayDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnNewEntry();
	afx_msg void OnFirst();
	afx_msg void OnLast();
	afx_msg void OnNext();
	afx_msg void OnPrevious();
	afx_msg void OnDelete();
	afx_msg void OnSave();
	afx_msg void OnOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STUDENT_CARRAYDLG_H__E87596D5_A5F4_4F46_A5FF_9B87DDA75E8F__INCLUDED_)
