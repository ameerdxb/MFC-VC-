#pragma once
class CMyStudent
{
public:
	CMyStudent();
	~CMyStudent();
};

