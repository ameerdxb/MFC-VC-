// SecondDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Student_CArray.h"
#include "SecondDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSecondDialog dialog
#include"Student.h"

CSecondDialog::CSecondDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSecondDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSecondDialog)
	m_Name2 = _T("");
	m_Regno2 = 0;
	m_Age2 = 0;
	m_Marks2 = 0;
	//}}AFX_DATA_INIT
}


void CSecondDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSecondDialog)
	DDX_Text(pDX, IDC_EDIT1, m_Name2);
	DDX_Text(pDX, IDC_EDIT5, m_Regno2);
	DDX_Text(pDX, IDC_EDIT6, m_Age2);
	DDX_Text(pDX, IDC_EDIT7, m_Marks2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSecondDialog, CDialog)
	//{{AFX_MSG_MAP(CSecondDialog)
	ON_BN_CLICKED(IDC_BUTTON1, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSecondDialog message handlers

void CSecondDialog::OnClose() 
{
	// TODO: Add your control notification handler code here


	


	DestroyWindow();
	
}

BOOL CSecondDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here;

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
