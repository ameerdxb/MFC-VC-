// Student_CArrayDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Student_CArray.h"
#include "Student_CArrayDlg.h"
#include "CStudDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
#include"SecondDialog.h"

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStudent_CArrayDlg dialog

CStudent_CArrayDlg::CStudent_CArrayDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStudent_CArrayDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStudent_CArrayDlg)
	m_Name = _T("");
	m_Regno = 0;
	m_Age = 0;
	m_Marks = 0;
	m_RecordNumber = _T("");
	m_nPos=0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CStudent_CArrayDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStudent_CArrayDlg)
	DDX_Text(pDX, IDC_EDIT1, m_Name);
	DDX_Text(pDX, IDC_EDIT2, m_Regno);
	DDX_Text(pDX, IDC_EDIT3, m_Age);
	DDX_Text(pDX, IDC_EDIT4, m_Marks);
	DDX_Text(pDX, IDC_RECORDNUMBER, m_RecordNumber);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CStudent_CArrayDlg, CDialog)
	//{{AFX_MSG_MAP(CStudent_CArrayDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnNewEntry)
	ON_BN_CLICKED(IDC_BUTTON3, OnFirst)
	ON_BN_CLICKED(IDC_BUTTON6, OnLast)
	ON_BN_CLICKED(IDC_BUTTON5, OnNext)
	ON_BN_CLICKED(IDC_BUTTON4, OnPrevious)
	ON_BN_CLICKED(IDC_BUTTON2, OnDelete)
	ON_BN_CLICKED(IDC_BUTTON7, OnSave)
	ON_BN_CLICKED(IDC_BUTTON8, OnOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStudent_CArrayDlg message handlers

BOOL CStudent_CArrayDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	CButton* bt;
	bt=(CButton*)GetDlgItem(IDC_BUTTON3);
		bt->EnableWindow(0);
		
	bt=(CButton*)GetDlgItem(IDC_BUTTON4);
		bt->EnableWindow(0);
		
	bt=(CButton*)GetDlgItem(IDC_BUTTON5);
		bt->EnableWindow(0);
		
	bt=(CButton*)GetDlgItem(IDC_BUTTON6);
		bt->EnableWindow(0);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CStudent_CArrayDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CStudent_CArrayDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CStudent_CArrayDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CStudent_CArrayDlg::OnNewEntry() 
{
	// TODO: Add your control notification handler code here
	CSecondDialog dlg;
	
	if(dlg.DoModal()==IDOK)
	{
		UpdateData(1);

		CStudent stud(dlg.m_Name2,dlg.m_Regno2,dlg.m_Age2,dlg.m_Marks2);

		arr.Add(stud);//adding student to CArray
		
	CButton* bt;	
	bt=(CButton*)GetDlgItem(IDC_BUTTON3);
		bt->EnableWindow(1);
		bt=(CButton*)GetDlgItem(IDC_BUTTON4);
		bt->EnableWindow(1);

		bt=(CButton*)GetDlgItem(IDC_BUTTON5);
		bt->EnableWindow(1);


		bt=(CButton*)GetDlgItem(IDC_BUTTON6);
		bt->EnableWindow(1);

	
		
	}
	

}

void CStudent_CArrayDlg::OnFirst() 
{
	// TODO: Add your control notification handler code here

	CStudent stud = arr[0];
	Display(stud); 
	CButton* bt=(CButton*)GetDlgItem(IDC_BUTTON4);
	bt->EnableWindow(0);
	bt=(CButton*)GetDlgItem(IDC_BUTTON5);
	bt->EnableWindow(1);
	m_nPos=0;
	
}

void CStudent_CArrayDlg::OnLast() 
{
	// TODO: Add your control notification handler code here


	int size=arr.GetSize();
	CStudent stud=arr[size-1];
	Display(stud);

	CButton* bt=(CButton*)GetDlgItem(IDC_BUTTON5);
	bt->EnableWindow(0);
	bt=(CButton*)GetDlgItem(IDC_BUTTON4);
	bt->EnableWindow(1);
	m_nPos=arr.GetUpperBound();
	
 
}

void CStudent_CArrayDlg::OnNext() 
{
	// TODO: Add your control notification handler code here
	
	
	if(m_nPos<arr.GetUpperBound() )
	{
		m_nPos++;
	CStudent stud=arr[m_nPos];
	Display(stud);
	CButton* bt=(CButton*)GetDlgItem(IDC_BUTTON4);
	bt->EnableWindow(1);
	}
	else if(m_nPos==arr.GetSize()-1)
	{
		CButton* bt=(CButton*)GetDlgItem(IDC_BUTTON5);
		bt->EnableWindow(0);
	}

	
}

void CStudent_CArrayDlg::OnPrevious() 
{
	// TODO: Add your control notification handler code here
	
	if(m_nPos>0)
	{
	m_nPos--;
	CStudent stud=arr[m_nPos];
	Display(stud);
	CButton* bt=(CButton*)GetDlgItem(IDC_BUTTON5);
	bt->EnableWindow(1);
	}
	else
	{
		CButton* bt=(CButton*)GetDlgItem(IDC_BUTTON4);
		bt->EnableWindow(0);
	}
	
}

void CStudent_CArrayDlg::Display(CStudent& stud)
{
 
	CString s;
 	s.Format("%d of %d",m_nPos+1, arr.GetSize());
	m_RecordNumber=s;
 

	m_Name=stud.getName();
	m_Regno=stud.getRegNo();
	m_Age=stud.getAge();
	m_Marks=stud.getMark();
	UpdateData(0);
}

void CStudent_CArrayDlg::OnDelete() 
{
	// TODO: Add your control notification handler code here
	arr.RemoveAt(m_nPos);
	m_Name="";
	m_Regno =0;
	m_Age =0;
	m_Marks =0;
	m_RecordNumber ="";
	UpdateData(0);
	
}

void CStudent_CArrayDlg::OnSave() 
{
	// TODO: Add your control notification handler code here
	CFile StudentInfoFile;
	StudentInfoFile.Open("Student Details.txt", CFile::modeCreate | CFile::modeWrite | CFile::modeNoTruncate);

	CArchive ArchiveInfo(&StudentInfoFile, CArchive::store);

	CStudent SerializeObj;

	ArchiveInfo << arr.GetSize();

	MessageBox("Save Button");

	for(int i=0;i<arr.GetSize();i++)
	{
		SerializeObj = arr[i];
		//Invoke the Serialize virtual function in Student class
		SerializeObj.Serialize(ArchiveInfo);

	}

	ArchiveInfo.Close();//Close the Archive
	StudentInfoFile.Close();//close the file
	
}

void CStudent_CArrayDlg::OnOpen() 
{
	// TODO: Add your control notification handler code here
	CFile StudentInfoFile;
	StudentInfoFile.Open("Student Details.txt", CFile::modeRead);

	CArchive ArchiveInfo(&StudentInfoFile,CArchive::load);

	int nStudentCount = 0;
	ArchiveInfo>>nStudentCount;

	CStudent SerializeObj;

	for(int i=0;i<nStudentCount;i++)
	{
		SerializeObj.Serialize(ArchiveInfo);
		//Invokes the else part of Serialize
		//of Student class - for Opening details

		SerializeObj = arr[i];
		Display(SerializeObj);

	}

	ArchiveInfo.Close();
	StudentInfoFile.Close();


	
}
