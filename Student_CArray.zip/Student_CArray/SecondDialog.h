#if !defined(AFX_SECONDDIALOG_H__2EC443E3_EE2F_4193_A8FC_6F5C02F722E6__INCLUDED_)
#define AFX_SECONDDIALOG_H__2EC443E3_EE2F_4193_A8FC_6F5C02F722E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SecondDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSecondDialog dialog

class CSecondDialog : public CDialog
{
// Construction
public:
	CSecondDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSecondDialog)
	enum { IDD = IDD_SECONDDIALOG };
	CString	m_Name2;
	int		m_Regno2;
	int		m_Age2;
	int		m_Marks2;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSecondDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSecondDialog)
	afx_msg void OnClose();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SECONDDIALOG_H__2EC443E3_EE2F_4193_A8FC_6F5C02F722E6__INCLUDED_)
