#pragma once

// CStudDialog dialog

class CStudDialog : public CDialog
{
	DECLARE_DYNAMIC(CStudDialog)

public:
	CStudDialog(CWnd* pParent = nullptr);   // standard constructor
	virtual ~CStudDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_NEWDIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
//	CString m_StudentName;
};
