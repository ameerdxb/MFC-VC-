// Student.h: interface for the CStudent class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STUDENT_H__C4F96FC5_5BE8_4322_90A3_5A67BC99EF4E__INCLUDED_)
#define AFX_STUDENT_H__C4F96FC5_5BE8_4322_90A3_5A67BC99EF4E__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CStudent  : public CObject
{

	DECLARE_SERIAL(CStudent)

public:
	void Serialize(CArchive& ar);
	CStudent();
	CStudent(CStudent& Sv)
	{
		*this = Sv;
	}
	CStudent(CString,int,int,int);
	CString getName();
	int getRegNo();
	int getAge();
	int getMark();
	virtual ~CStudent();

	CStudent& operator=(CStudent& SvFi);
	
private:
	CString m_szName;
	int m_nRegNo;
	int m_nAge;
	int m_nMark;

};



#endif // !defined(AFX_STUDENT_H__C4F96FC5_5BE8_4322_90A3_5A67BC99EF4E__INCLUDED_)
