// Student.cpp: implementation of the CStudent class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Student_CArray.h"
#include "Student.h"
#include "Student_CArrayDlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL(CStudent,CObject,1)

CStudent::CStudent()
{

}

CStudent::~CStudent()
{

}

CString CStudent::getName()
{
	return m_szName;
}

int CStudent::getRegNo()
{
	return m_nRegNo;
}

int CStudent::getAge()
{
	return m_nAge;
}

int CStudent::getMark()
{
	return m_nMark;
}


CStudent::CStudent(CString name,int regno,int age,int mark)
{
	m_szName=name;
	m_nRegNo=regno;
	m_nAge=age;
	m_nMark=mark;
}
 
void CStudent::Serialize(CArchive &pArchive)
{
	AfxMessageBox("Serialize of Student");

	if(pArchive.IsStoring())
	{
		AfxMessageBox("Storing...");

		CStudent_CArrayDlg* dlg = (CStudent_CArrayDlg*)AfxGetMainWnd();

		for(int i=0;i<dlg->arr.GetSize();i++)
		{
			pArchive<<dlg->arr[i].m_szName<<dlg->arr[i].m_nAge<<dlg->arr[i].m_nRegNo<<dlg->arr[i].m_nMark;
		}//for loop
	}//IsStoring()
	
	else
	{
		CStudent_CArrayDlg* dlg = (CStudent_CArrayDlg*)AfxGetMainWnd();
		CStudent StuObj;
		
		pArchive>>StuObj.m_szName>>StuObj.m_nAge>>StuObj.m_nRegNo>>StuObj.m_nMark;
		dlg->arr.Add(StuObj);
	}
 
}

CStudent& CStudent::operator =(CStudent& SvFo)
{
	 m_szName=SvFo.m_szName;
	 m_nAge=SvFo.m_nAge;
   	 m_nRegNo=SvFo.m_nRegNo;
	 m_nMark=SvFo.m_nMark;

	return *this;
}