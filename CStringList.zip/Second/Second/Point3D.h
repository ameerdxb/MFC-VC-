#include "pch.h"
class CPoint3D
{
public:
	CPoint3D()
	{
		x = y = z = 0;
	}
	CPoint3D(int xPos, int yPos, int zPos)
	{
		x = xPos;
		y = yPos;
		z = zPos;
	}
	void Display()const
	{

	}
//private:
	int x, y, z;
};
