
// SecondDlg.h : header file
//

#pragma once
#include "Point3D.h"

// CSecondDlg dialog
class CSecondDlg : public CDialogEx
{
// Construction
public:
	CSecondDlg(CWnd* pParent = nullptr);	// standard constructor
	CArray<CPoint3D, CPoint3D&> array;
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SECOND_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
//	CListBox m_List;
	afx_msg void OnAddToArray();
	afx_msg void OnDisplayFromArray();


	CListBox test;
	afx_msg void OnLbnSelchangeList2();
	
	CStringList list;

	afx_msg void OnBnClickedButton3();
};
