// CMyPage1.cpp : implementation file
//

#include "pch.h"
#include "MFCAssignment3.h"
#include "CMyPage1.h"
#include "afxdialogex.h"


// CMyPage1 dialog

IMPLEMENT_DYNAMIC(CMyPage1, CPropertyPage)

CMyPage1::CMyPage1()
	: CPropertyPage(IDD_DIALOG1)
	, m_PatientID(_T(""))
	, m_PatientName(_T(""))
	, m_DateRegistration(_T(""))
	, m_Height(_T(""))
	, m_Weight(_T(""))
	, m_Study(_T(""))
	, m_nImages(_T(""))
	, m_OperatorName(_T(""))
	, m_AgeEdit(_T(""))
	, m_BodyValue(_T(""))
	, m_AgeValue(_T(""))
{

}

CMyPage1::~CMyPage1()
{
}

void CMyPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_PatientID);
	DDX_Text(pDX, IDC_EDIT2, m_PatientName);
	DDX_Control(pDX, IDC_RADIO1, m_Male);
	DDX_Control(pDX, IDC_RADIO2, m_Female);
	DDX_Text(pDX, IDC_DATETIMEPICKER1, m_DateRegistration);
	DDX_Text(pDX, IDC_EDIT3, m_Height);
	DDX_Text(pDX, IDC_EDIT4, m_Weight);
	DDX_Text(pDX, IDC_EDIT5, m_Study);
	DDX_Text(pDX, IDC_EDIT6, m_nImages);
	DDX_Text(pDX, IDC_EDIT7, m_OperatorName);
	DDX_Control(pDX, IDC_COMBO1, m_Age);
	DDX_Control(pDX, IDC_COMBO2, m_BodyPart);
	DDX_Control(pDX, IDC_LIST1, m_List);
	DDX_Text(pDX, IDC_EDIT8, m_AgeEdit);
	DDX_CBString(pDX, IDC_COMBO2, m_BodyValue);
	DDX_CBString(pDX, IDC_COMBO1, m_AgeValue);
	DDX_Control(pDX, IDC_EDIT1, m_PatIDControl);
}


BEGIN_MESSAGE_MAP(CMyPage1, CPropertyPage)
	ON_NOTIFY(DTN_DATETIMECHANGE, IDC_DATETIMEPICKER1, &CMyPage1::OnDtnDatetimechangeDatetimepicker1)
	ON_BN_CLICKED(IDC_BUTTON3, &CMyPage1::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON1, &CMyPage1::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CMyPage1::OnBnClickedButton2)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST1, &CMyPage1::OnLvnItemchangedList1)
END_MESSAGE_MAP()


// CMyPage1 message handlers


void CMyPage1::OnDtnDatetimechangeDatetimepicker1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMDATETIMECHANGE pDTChange = reinterpret_cast<LPNMDATETIMECHANGE>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
}


BOOL CMyPage1::OnInitDialog()
{
	CPropertyPage::OnInitDialog();

	// TODO:  Add extra initialization here
	m_List.InsertColumn(0, _T("Patient ID"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(1, _T("Patient Name"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(2, _T("Gender"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(3, _T("Date of Reg."), LVCFMT_LEFT, 120);
	m_List.InsertColumn(4, _T("Age"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(5, _T("Months/Years"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(6, _T("Height"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(7, _T("Weight"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(8, _T("Study Comment"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(9, _T("Body Part"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(10, _T("No. of Image"), LVCFMT_LEFT, 120);
	m_List.InsertColumn(11, _T("Operator Name"), LVCFMT_LEFT, 120);

	m_Age.AddString(_T("Years"));
	m_Age.AddString(_T("Months"));

	m_BodyPart.AddString(_T("Head"));
	m_BodyPart.AddString(_T("Hand"));
	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}

//Button Register
void CMyPage1::OnBnClickedButton3()
{
	// TODO: Add your control notification handler code here
	CString m_Gender;
	if (m_Male.GetCheck())
	/// Set.Check is for making it checked while running the pgm///// GetCheck() is for checking whether it is selected or not

	{
		m_Gender = _T("Male");
	}
	if (m_Female.GetCheck())
	{
		m_Gender = _T("Female");
	}
	UpdateData(TRUE);
	//	MessageBox(str);
	int nIndex = m_List.InsertItem(0, m_PatientID);
	m_List.SetItemText(nIndex, 1, m_PatientName);
	m_List.SetItemText(nIndex, 2, m_Gender);
	m_List.SetItemText(nIndex, 3, m_DateRegistration);
	m_List.SetItemText(nIndex, 4, m_AgeEdit);
	m_List.SetItemText(nIndex, 5, m_AgeValue);
	m_List.SetItemText(nIndex, 6, m_Height);
	m_List.SetItemText(nIndex, 7, m_Weight);
	m_List.SetItemText(nIndex, 8, m_Study);
	m_List.SetItemText(nIndex, 9, m_BodyValue);
	m_List.SetItemText(nIndex, 10, m_nImages);
	m_List.SetItemText(nIndex, 11, m_OperatorName);

	PATIENT_INFO_t std;
	std.m_sPatientID = m_PatientID;
	std.m_sPatientName = m_PatientName;

	if (m_Male.GetCheck())
		/// Set.Check is for making it checked while running the pgm///// GetCheck() is for checking whether it is selected or not
	{
		std.m_sGender = _T("Male");
	}
	if (m_Female.GetCheck())
	{
		std.m_sGender = _T("Female");
	}
	
	std.m_PatientDateofReg = m_DateRegistration;
	std.m_sAge = m_AgeValue;
	std.oStudy.m_sHeight = m_Height;
	std.oStudy.m_sWeight = m_Weight;
	std.oStudy.m_sStudyComments = m_Study;
	std.oStudy.oSeries.m_sBodyPart= m_BodyValue;
	std.oStudy.oSeries.m_sNumberofImages = m_nImages;
	std.oStudy.oSeries.m_sOperatorsName = m_OperatorName;

	AfxGetMainWnd()->SendMessage(WM_USER_SECONDPAGE, (WPARAM)&std, 0);
	UpdateData(FALSE);

}

//Button Clear
void CMyPage1::OnBnClickedButton1()
{
	// TODO: Add your control notification handler code here
	UpdateData(1);
	m_PatientID.Empty();
	m_PatientName.Empty();
	m_Male.SetCheck(BST_UNCHECKED);
	m_Female.SetCheck(BST_UNCHECKED);
	m_DateRegistration.Empty();
	m_AgeEdit.Empty();
	m_AgeValue.Empty();
	m_Height.Empty();
	m_Weight.Empty();
	m_Study.Empty();
	m_BodyValue.Empty();
	m_nImages.Empty();
	m_OperatorName.Empty();

	UpdateData(0);

}

//Button Emergency ID
void CMyPage1::OnBnClickedButton2()
{
	// TODO: Add your control notification handler code here
	UpdateData(1);
	CTime oTime = CTime::GetCurrentTime();
	// we can only display time as CString 
	CString sTime1 = oTime.Format(_T("EM_ID_%D%H%M%S"));
	m_PatientID = sTime1;
	m_PatIDControl.EnableWindow(FALSE);
	CString sTime2 = oTime.Format(_T("EM_NAME_%D%H%M%S"));
	m_PatientName = sTime2;
	UpdateData(0);

}


void CMyPage1::OnLvnItemchangedList1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: Add your control notification handler code here
	UpdateData(1);
	m_PatientID = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem);
	m_PatientName = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem+1);
	CString gender= m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem+2);

	if (gender = "Male")
		m_Male.SetCheck(1);
	else
		m_Female.SetCheck(1);

	CString str = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem + 3);
	m_DateRegistration.SetString(str);

	m_AgeEdit = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem + 4);
	m_AgeValue = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem+5);
	m_Height = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem+6);
	m_Weight = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem + 7);
	m_Study= m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem + 8);
	m_BodyValue = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem + 9);
	m_nImages= m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem + 10);
	m_OperatorName = m_List.GetItemText(pNMLV->iItem, pNMLV->iSubItem + 11);

	UpdateData(0);
	*pResult = 0;
}
