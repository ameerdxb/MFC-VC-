// CMyPropertySheet.cpp : implementation file
//

#include "pch.h"
#include "MFCAssignment3.h"
#include "CMyPropertySheet.h"



// CMyPropertySheet

IMPLEMENT_DYNAMIC(CMyPropertySheet, CPropertySheet)

CMyPropertySheet::CMyPropertySheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
#ifndef _WIN32_WCE
	EnableActiveAccessibility();
#endif

}

CMyPropertySheet::CMyPropertySheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
#ifndef _WIN32_WCE
	EnableActiveAccessibility();
#endif
	AddPage(&P1);
	AddPage(&P2);
}

CMyPropertySheet::~CMyPropertySheet()
{
}

LRESULT CMyPropertySheet::OnSecondPage(WPARAM wp, LPARAM lp)
{
	MessageBox(_T("FromPropertySheet"));
	P2.SendMessage(WM_USER_SECONDPAGE, wp, lp);
	return 0L;
	//return LRESULT();
}


BEGIN_MESSAGE_MAP(CMyPropertySheet, CPropertySheet)
	ON_MESSAGE(WM_USER_SECONDPAGE, &CMyPropertySheet::OnSecondPage)
END_MESSAGE_MAP()


// CMyPropertySheet message handlers


BOOL CMyPropertySheet::OnInitDialog()
{
	BOOL bResult = CPropertySheet::OnInitDialog();

	// TODO:  Add your specialized code here
	CButton* pBtn;
	pBtn = (CButton*)GetDlgItem(IDOK);
	pBtn->ShowWindow(SW_HIDE);
	pBtn = (CButton*)GetDlgItem(IDCANCEL);
	pBtn->ShowWindow(SW_HIDE);
	pBtn = (CButton*)GetDlgItem(ID_APPLY_NOW);
	pBtn->ShowWindow(SW_HIDE);
	pBtn = (CButton*)GetDlgItem(IDHELP);
	pBtn->ShowWindow(SW_HIDE);

	return bResult;
}
