//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PatientData.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     132
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1007
#define IDC_COMMENTS                    1008
#define IDC_COMBO1                      1009
#define IDC_WEIGHT                      1010
#define IDC_ID                          1011
#define IDC_IMAGES                      1012
#define IDC_OPERATOR                    1013
#define IDC_CLEAR                       1014
#define IDC_EMERGENCYID                 1015
#define IDC_REGISTER                    1016
#define IDC_SCAN                        1017
#define IDC_NAME                        1018
#define IDC_AGE                         1020
#define IDC_HEIGHT                      1021
#define IDC_DATETIMEPICKER1             1022
#define IDC_LIST1                       1023
#define IDC_TREE1                       1025
#define IDC_LIST2                       1026
#define IDC_BUTTON1                     1027
#define IDC_BUTTON2                     1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
