
// Q1TourDlg.cpp : implementation file
//

#include "pch.h"
#include "framework.h"
#include "Q1Tour.h"
#include "Q1TourDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CQ1TourDlg dialog



CQ1TourDlg::CQ1TourDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_Q1TOUR_DIALOG, pParent)
	, m_nValue(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CQ1TourDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_nValue);
}

BEGIN_MESSAGE_MAP(CQ1TourDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RADIO4, &CQ1TourDlg::OnBnClickedRadio4)
	ON_BN_CLICKED(IDC_RADIO1, &CQ1TourDlg::OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_CHECK2, &CQ1TourDlg::OnBnClickedCheck2)
	ON_BN_CLICKED(IDC_RADIO3, &CQ1TourDlg::OnBnClickedRadio3)
	ON_BN_CLICKED(IDC_RADIO2, &CQ1TourDlg::OnBnClickedRadio2)
	ON_BN_CLICKED(IDC_CHECK1, &CQ1TourDlg::OnBnClickedCheck1)
	ON_EN_CHANGE(IDC_EDIT1, &CQ1TourDlg::OnEnChangeEdit1)
END_MESSAGE_MAP()


// CQ1TourDlg message handlers

BOOL CQ1TourDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CQ1TourDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CQ1TourDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CQ1TourDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CQ1TourDlg::OnBnClickedRadio4()
{
	// TODO: Add your control notification handler code here
	m_nValue = 8000;
	CheckDlgButton(IDC_CHECK1, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK2, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK3, BST_CHECKED);
	CheckDlgButton(IDC_CHECK4, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK5, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK6, BST_CHECKED);
	CheckDlgButton(IDC_CHECK7, BST_CHECKED);
	UpdateData(0);
}


void CQ1TourDlg::OnBnClickedRadio1()
{
	// TODO: Add your control notification handler code here
	// ooty
	m_nValue = 5000;
	CheckDlgButton(IDC_CHECK1, BST_CHECKED);
	CheckDlgButton(IDC_CHECK2, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK3, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK4, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK5, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK6, BST_CHECKED);
	CheckDlgButton(IDC_CHECK7, BST_CHECKED);
	UpdateData(0);

}


void CQ1TourDlg::OnBnClickedCheck2()
{
	// TODO: Add your control notification handler code here
}


void CQ1TourDlg::OnBnClickedRadio3()
{
	// TODO: Add your control notification handler code here
	m_nValue = 7000;
	CheckDlgButton(IDC_CHECK1, BST_CHECKED);
	CheckDlgButton(IDC_CHECK2, BST_CHECKED);
	CheckDlgButton(IDC_CHECK3, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK4, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK5, BST_CHECKED);
	CheckDlgButton(IDC_CHECK6, BST_CHECKED);
	CheckDlgButton(IDC_CHECK7, BST_CHECKED);
	UpdateData(0);
}


void CQ1TourDlg::OnBnClickedRadio2()
{
	// TODO: Add your control notification handler code here
	m_nValue = 6000;
	CheckDlgButton(IDC_CHECK1, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK2, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK3, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK4, BST_CHECKED);
	CheckDlgButton(IDC_CHECK5, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK6, BST_CHECKED);
	CheckDlgButton(IDC_CHECK7, BST_CHECKED);
	UpdateData(0);
}


void CQ1TourDlg::OnBnClickedCheck1()
{
	// TODO: Add your control notification handler code here
}


void CQ1TourDlg::OnEnChangeEdit1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
