// MyTreeControlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MyTreeControl.h"
#include "MyTreeControlDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
 
// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
 

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyTreeControlDlg dialog

CMyTreeControlDlg::CMyTreeControlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyTreeControlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyTreeControlDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyTreeControlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyTreeControlDlg)
	DDX_Control(pDX, IDC_LIST2, m_List2);
	DDX_Control(pDX, IDC_LIST1, m_List);
	DDX_Control(pDX, IDC_TREE1, m_Tree);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyTreeControlDlg, CDialog)
	//{{AFX_MSG_MAP(CMyTreeControlDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TVN_ITEMEXPANDING, IDC_TREE1, OnItemexpandingTree1)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnSelchangedTree1)
	ON_NOTIFY(NM_RCLICK, IDC_TREE1, OnRclickTree1)
	ON_COMMAND(ID_MENU_EXPAND, OnMenuExpand)
	ON_COMMAND(ID_MENU_COLLAPSE, OnMenuCollapse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyTreeControlDlg message handlers

BOOL CMyTreeControlDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	hRoot = m_Tree.InsertItem("Vegetables");
	hPumpkin = m_Tree.InsertItem("Pumpkin",hRoot); 
	m_Tree.InsertItem("Orange Pumpkin",hPumpkin);

	hPumpkin = m_Tree.InsertItem("New Pumpkin", hRoot);
	m_Tree.InsertItem("Green Pumpkin", hPumpkin);

	hRoot=m_Tree.InsertItem("Fruits");
	hApple=m_Tree.InsertItem("Apple",hRoot); 
	hGrapes=m_Tree.InsertItem("Grapes",hApple); 

	m_Tree.InsertItem("Green Grapes",hGrapes);
	m_Tree.InsertItem("Black Grapes",hGrapes);

	m_List.InsertColumn(0,"Type",LVCFMT_LEFT,120);
	m_Image.Create(IDB_HEAD,32,1,RGB(255,0,0));
	
	m_List2.SetImageList(&m_Image,LVSIL_NORMAL);


	//m_List.InsertColumn(1,"SubType",LVCFMT_LEFT,120);

	m_TreeContextMenu.LoadMenu(IDR_MENU1);	
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyTreeControlDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyTreeControlDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMyTreeControlDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMyTreeControlDlg::OnItemexpandingTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
/*	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	HTREEITEM hMyItem=pNMTreeView->itemNew.hItem;
	
	CString str = m_Tree.GetItemText(hMyItem);
	  //MessageBox("Hello "+str);

	
	int nIndex=0;
	if(pNMTreeView->action==TVE_EXPAND)
	nIndex=m_List.InsertItem(0,str);//adding to listcontrol
	 
	
	*pResult = 0;*/
}

void CMyTreeControlDlg::OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	HTREEITEM hMyItem=pNMTreeView->itemNew.hItem;
	
	CString str = m_Tree.GetItemText(hMyItem);
	  //MessageBox("Hello "+str);

	
	int nIndex=0;

	nIndex=m_List.InsertItem(0,str);//adding to listcontrol

	HANDLE hBitMap = ::LoadImage(AfxGetInstanceHandle(),"D:\\MyTreeControl\\res\\Head.bmp",IMAGE_BITMAP,0,0,LR_LOADFROMFILE);

	CBitmap myBitmap;
	myBitmap.Attach((HBITMAP)hBitMap);
	m_Image.Add(&myBitmap,RGB(0,255,0));	

	nIndex=m_List2.InsertItem(0,"Head");
	*pResult = 0;
}

void CMyTreeControlDlg::OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	

	CMenu* pPopupMenu;

	pPopupMenu = m_TreeContextMenu.GetSubMenu(0);

	CPoint MousePos;
	GetCursorPos(&MousePos);

	pPopupMenu->TrackPopupMenu(TPM_LEFTALIGN,MousePos.x,MousePos.y,this);

	 
	*pResult = 0;
}

void CMyTreeControlDlg::OnMenuExpand() 
{
	// TODO: Add your command handler code here
	HTREEITEM hitem = m_Tree.GetRootItem();
	ExpandAllItems(hitem);	
}

void CMyTreeControlDlg::OnMenuCollapse() 
{
	// TODO: Add your command handler code here
	HTREEITEM hitem = m_Tree.GetRootItem();
	ExpandAllItems(hitem,true);
	
}

void CMyTreeControlDlg::ExpandAllItems(HTREEITEM hItemParent_i, bool expand)
{
	HTREEITEM hItemHandle;
	if(m_Tree.ItemHasChildren(hItemParent_i))
	{
		if(!expand)
		{
			m_Tree.Expand(hItemParent_i,TVE_EXPAND);
		}

		else
		{
			m_Tree.Expand(hItemParent_i,TVE_COLLAPSE);
		}

		hItemHandle = m_Tree.GetChildItem(hItemParent_i);
		
		if(NULL != hItemHandle)
		{
			ExpandAllItems(hItemHandle,expand);
		}

		hItemHandle = m_Tree.GetNextItem(hItemParent_i,TVGN_NEXT);

		if(NULL != hItemHandle)
		{
			ExpandAllItems(hItemHandle,expand);
		}
		
	}

}
