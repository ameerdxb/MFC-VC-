// MyTreeControlDlg.h : header file
//

#if !defined(AFX_MYTREECONTROLDLG_H__FC9233C2_1D45_4E54_88A6_A594FCE883AD__INCLUDED_)
#define AFX_MYTREECONTROLDLG_H__FC9233C2_1D45_4E54_88A6_A594FCE883AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMyTreeControlDlg dialog

class CMyTreeControlDlg : public CDialog
{
// Construction
public:
	void ExpandAllItems(HTREEITEM hitem,bool expand = false);
	CMyTreeControlDlg(CWnd* pParent = NULL);	// standard constructor
	CMenu m_TreeContextMenu;

// Dialog Data
	//{{AFX_DATA(CMyTreeControlDlg)
	enum { IDD = IDD_MYTREECONTROL_DIALOG };
	CListCtrl	m_List2;
	CListCtrl	m_List;
	CTreeCtrl	m_Tree;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyTreeControlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	HTREEITEM hRoot,hPumpkin,hApple,hGrapes;
	CImageList m_Image;
	


	// Generated message map functions
	//{{AFX_MSG(CMyTreeControlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnItemexpandingTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMenuExpand();
	afx_msg void OnMenuCollapse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYTREECONTROLDLG_H__FC9233C2_1D45_4E54_88A6_A594FCE883AD__INCLUDED_)
