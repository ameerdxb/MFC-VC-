// Files and Collection ClassDlg.h : header file
//

#if !defined(AFX_FILESANDCOLLECTIONCLASSDLG_H__2F17A5DE_20CA_4903_B6F7_9C1CDE6B4FAC__INCLUDED_)
#define AFX_FILESANDCOLLECTIONCLASSDLG_H__2F17A5DE_20CA_4903_B6F7_9C1CDE6B4FAC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFilesandCollectionClassDlg dialog
#include "afxcoll.h"

class CFilesandCollectionClassDlg : public CDialog
{
// Construction
public:
	void ParseFileContents(CString& strFileData);
	void ReadContents();
	CFilesandCollectionClassDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFilesandCollectionClassDlg)
	enum { IDD = IDD_FILESANDCOLLECTIONCLASS_DIALOG };
	CComboBox	m_Combo;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilesandCollectionClassDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CStringArray arr;
	HICON m_hIcon;
	CFile file;

	// Generated message map functions
	//{{AFX_MSG(CFilesandCollectionClassDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAdd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILESANDCOLLECTIONCLASSDLG_H__2F17A5DE_20CA_4903_B6F7_9C1CDE6B4FAC__INCLUDED_)
